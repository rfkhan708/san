#ifndef PF_ON_QUEUE_H
#define PF_ON_QUEUE_H


class PF_On_Queue
{
    public:
        PF_On_Queue();
        virtual ~PF_On_Queue();
    protected:
    private:
};

#endif // PF_ON_QUEUE_H
